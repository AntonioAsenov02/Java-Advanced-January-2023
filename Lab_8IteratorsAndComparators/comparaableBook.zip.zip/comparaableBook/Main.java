package comparaableBook;

public class Main {

    public static void main(String[] args) {

        Book book1 = new Book("Animal Farm", 2003, "George Orwell");
        Book book2 = new Book("Alice in WonderLand",2005,"Tom Ford");
        Book book3 = new Book("Some Book",2009,"Who");
    }
}
